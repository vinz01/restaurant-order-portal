/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author admin
 */
import javax.swing.*;  
public class jpanebooking {
    JFrame f;  
jpanebooking(){  
    f=new JFrame();  
    JOptionPane.showMessageDialog(f,"You are our priority. Thank you for booking!");  
}  
public static void main(String[] args) {  
    new jpanebooking();  
}  
}  

